package android.com.dukanchalo_muzaffarpur;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {
    WebView webviewws;
    ProgressDialog progressDialog;
    private String weburl="https://dukanchalo.company.site/";
    ProgressBar webs ;

    RelativeLayout relative;
    Button no_connection;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window =getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        webviewws = (WebView) findViewById(R.id.myweb);
        webs = (ProgressBar) findViewById(R.id.progress_bar);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait");

        no_connection = (Button) findViewById(R.id.btn_noconnection);
        relative = (RelativeLayout) findViewById(R.id.relative);

        webviewws.loadUrl(weburl);
        webviewws.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return  true;
            }
        });
        webviewws.setWebChromeClient(new WebChromeClient(){
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                webs.setVisibility(View.VISIBLE);
                webs.setProgress(newProgress);
                setTitle("Loading...");
                progressDialog.show();
                if(newProgress == 100){
                    webs.setVisibility(View.GONE);
                    setTitle(view.getTitle());
                    progressDialog.dismiss();
                }
                super.onProgressChanged(view, newProgress);
            }
        });

        webviewws.getSettings().setDomStorageEnabled(true);
        webviewws.getSettings().setLoadsImagesAutomatically(true);
        webviewws.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        webviewws.getSettings().setJavaScriptEnabled(true);


    }

    @Override
    public void onBackPressed() {
        if(webviewws.canGoBack()){
            webviewws.goBack();
        }
        else {
            super.onBackPressed();
        }
    }
  
}